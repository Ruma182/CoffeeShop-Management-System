# CoffeeShop-Management-System
A console-based C++ project for managing a coffee shop
