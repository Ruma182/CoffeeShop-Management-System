package Interface;
import Employeee.*;
public interface IinterfaceEmployee{

     void addEmployee (Employee e);
     void showAllChef();
	
}