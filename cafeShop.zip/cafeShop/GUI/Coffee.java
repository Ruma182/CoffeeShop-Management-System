package GUI;
import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Coffee extends JFrame implements ActionListener
{
	Font font = new Font ("Speak pro Light" , Font.BOLD , 80);
	private JPanel panel;
	private JButton next;
	private JLabel background, title;
	private ImageIcon icon = new ImageIcon ("Image/bank.png");
	private ImageIcon icon1 = new ImageIcon ("Image/coffe_new_resized.jpg");
	
	public Coffee ()
	{
		super("My Coffee Shop");
		this.setSize(1200,675);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setLocationRelativeTo(null);
		this.setIconImage(icon.getImage());
		
		panel = new JPanel();
		panel.setLayout(null);
		panel.setBounds(0,0,1200,675);
		panel.setOpaque(false);
		this.add(panel);
		this.setLayout(null);
		
		background = new JLabel(icon1);
		background.setBounds(0,0,1200,675);
		this.add(background);
		this.add(background);
		
		
		title = new JLabel ("Welcome");
		title.setBounds(60,0,1200,300);
		title.setFont(font);
		title.setForeground(Color.WHITE);
		panel.add(title);
		
		
		next = new JButton("NEXT..");
		next.setFont(new Font("Speak pro Light" , Font.PLAIN , 25));
		next.setBounds(970,550,170,50);
		next.setFocusPainted(false);
		next.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		next.addActionListener(this);
		panel.add(next);
		
}
		public void actionPerformed(ActionEvent ae)
		{
			
			if(next == ae.getSource())
			{
			    FirstPage first = new FirstPage ();
				this.setVisible(false);
				first.setVisible(true);
			}
			else {
				System.out.println("==========");
			}
		}
}