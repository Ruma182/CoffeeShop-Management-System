import java.lang.*;
import javax.swing.SwingUtilities;
import GUI.Coffee;

public class Start
{
	public static void main(String [] args)
	{
		SwingUtilities.invokeLater(new Runnable(){
			public void run(){
				
				Coffee coffe = new Coffee();
				coffe.setVisible(true);
			}
		});
	}
}